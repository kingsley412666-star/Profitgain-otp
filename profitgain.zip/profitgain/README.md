# ProfitGain — Investment Platform

A complete investment platform with deposit, withdraw, and fixed-term investment products.

## Features

- **3 Investment Products** with selectable lock periods (days)
- Deposit / Withdraw flows
- Separate histories: Deposits, Withdrawals, Product Purchases
- Black + Yellow / White + Yellow theme toggle
- Registration & Login → Dashboard
- Clean structure ready for real payment API integration (no fake deposits)

## How to Run

1. Open `index.html` in a browser (or serve the folder with any static server).
2. Click **Get Started** → Register an account.
3. Deposit funds (demo mode simulates verified payment).
4. Go to **Invest** → choose a product + lock days → confirm.
5. View everything in Dashboard and History.

## Theme Toggle

Click the sun/moon icon in the top right on any page to switch between:
- Dark mode → Black + Yellow
- Light mode → White + Yellow

## Important: Payment Integration

The deposit page currently runs in **demo mode** (localStorage only).

To prevent phony deposits in production:

1. Replace the demo deposit logic with a real payment provider (Stripe, Paystack, Flutterwave, etc.).
2. Only credit the user balance **after** a verified webhook from the payment provider.
3. Never credit balance on the frontend alone.

## File Structure

```
profitgain/
├── index.html          # Homepage
├── register.html
├── login.html
├── dashboard.html
├── deposit.html
├── withdraw.html
├── invest.html
├── history.html
├── css/styles.css
├── js/
│   ├── theme.js
│   └── home.js
└── README.md
```

## Next Steps (when you are ready)

- Connect real payment APIs
- Add backend (Node / Python) + database
- Add email verification, 2FA, admin panel
- Live maturity & automatic payout logic

Built for you with clean architecture and production-minded design.
