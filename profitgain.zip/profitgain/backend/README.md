# ProfitGain OTP Backend (TXTARO)

## Quick Start (on a computer)

```bash
cd backend
npm install
npm start
```

Backend will run at: **http://localhost:3000**

### Endpoints
- `POST /api/otp/send`   → body: `{ "phone": "+233241234567" }`
- `POST /api/otp/verify` → body: `{ "phone": "+233241234567", "code": "123456" }`
- `POST /api/webhooks/txtaro` → for TXTARO webhook events

## Connect the website

1. Open `register.html`
2. Set:
```js
var DEMO_MODE = false;
var BACKEND_URL = 'http://localhost:3000';
```
3. Open the website and register with a real Ghana number
4. You will receive a real SMS OTP from TXTARO

## Deploy online (so it works on your phone)

Because your phone cannot reach `localhost`, host the backend:

### Free options
- **Render.com** → New Web Service → connect this folder → start command: `node server.js`
- **Railway.app**
- **Fly.io**

After deploy you get a URL like:
`https://profitgain-otp.onrender.com`

Then in `register.html` set:
```js
var DEMO_MODE = false;
var BACKEND_URL = 'https://profitgain-otp.onrender.com';
```

## TXTARO Webhook (optional)

In TXTARO dashboard → OTP / API Manager → Webhook URL:
```
https://YOUR-BACKEND-URL/api/webhooks/txtaro
```

## Security

- API key is in `server.js` (or better: use environment variable `TXTARO_API_KEY`)
- Never put the API key in the website (HTML/JS)
- Rotate the key in TXTARO after testing if it was shared
