// Homepage GSAP Animations (TransFlow-style text motion)
gsap.registerPlugin(ScrollTrigger);

// Hero entrance
const heroTl = gsap.timeline({ defaults: { ease: 'power3.out' } });

heroTl
  .to('.hero-label', { opacity: 1, y: 0, duration: 0.6, delay: 0.2 })
  .to('.hero-title', { opacity: 1, y: 0, duration: 0.8 }, '-=0.3')
  .to('.hero-sub', { opacity: 1, y: 0, duration: 0.7 }, '-=0.4')
  .to('.hero-cta', { opacity: 1, y: 0, duration: 0.6 }, '-=0.3');

// Set initial states
gsap.set(['.hero-label', '.hero-title', '.hero-sub', '.hero-cta'], { y: 30 });

// Stats
gsap.from('.stat-item', {
  scrollTrigger: {
    trigger: '.stat-item',
    start: 'top 85%',
  },
  opacity: 0,
  y: 40,
  duration: 0.7,
  stagger: 0.12,
  ease: 'power2.out'
});

// Section titles
gsap.utils.toArray('.section-title').forEach(el => {
  gsap.from(el, {
    scrollTrigger: { trigger: el, start: 'top 85%' },
    opacity: 0,
    y: 40,
    duration: 0.8,
    ease: 'power3.out'
  });
});

gsap.utils.toArray('.section-sub').forEach(el => {
  gsap.from(el, {
    scrollTrigger: { trigger: el, start: 'top 85%' },
    opacity: 0,
    y: 30,
    duration: 0.7,
    delay: 0.1,
    ease: 'power2.out'
  });
});

// Product cards
gsap.from('.product-card', {
  scrollTrigger: {
    trigger: '#products',
    start: 'top 75%',
  },
  opacity: 0,
  y: 60,
  duration: 0.8,
  stagger: 0.15,
  ease: 'power3.out'
});

// Steps
gsap.from('.step-card', {
  scrollTrigger: {
    trigger: '#how',
    start: 'top 75%',
  },
  opacity: 0,
  y: 50,
  duration: 0.7,
  stagger: 0.12,
  ease: 'power2.out'
});

// CTA
gsap.from(['.cta-title', '.cta-sub', '.cta-btn'], {
  scrollTrigger: {
    trigger: '.cta-title',
    start: 'top 85%',
  },
  opacity: 0,
  y: 30,
  duration: 0.7,
  stagger: 0.12,
  ease: 'power2.out'
});
