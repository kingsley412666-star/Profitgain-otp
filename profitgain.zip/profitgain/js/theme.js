(function () {
  function applyTheme(theme) {
    var html = document.documentElement;
    html.setAttribute('data-theme', theme);
    try { localStorage.setItem('profitgain-theme', theme); } catch(e) {}

    // Force critical colors so nothing becomes invisible
    if (theme === 'dark') {
      html.style.background = '#0A0A0A';
      if (document.body) {
        document.body.style.background = '#0A0A0A';
        document.body.style.color = '#F5F5F5';
      }
    } else {
      html.style.background = '#FFFFFF';
      if (document.body) {
        document.body.style.background = '#FFFFFF';
        document.body.style.color = '#111111';
      }
    }

    var moon = document.getElementById('icon-moon');
    var sun = document.getElementById('icon-sun');
    if (moon && sun) {
      if (theme === 'dark') {
        moon.style.display = 'block';
        sun.style.display = 'none';
      } else {
        moon.style.display = 'none';
        sun.style.display = 'block';
      }
    }
  }

  var saved = 'dark';
  try { saved = localStorage.getItem('profitgain-theme') || 'dark'; } catch(e) {}
  applyTheme(saved);

  function bindToggle() {
    var toggle = document.getElementById('theme-toggle');
    if (!toggle) return;
    var newBtn = toggle.cloneNode(true);
    toggle.parentNode.replaceChild(newBtn, toggle);

    function switchTheme(e) {
      if (e) { e.preventDefault(); e.stopPropagation(); }
      var current = document.documentElement.getAttribute('data-theme') || 'dark';
      applyTheme(current === 'dark' ? 'light' : 'dark');
    }

    newBtn.addEventListener('click', switchTheme);
    newBtn.addEventListener('touchend', switchTheme, {passive: false});
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bindToggle);
  } else {
    bindToggle();
  }
})();
