# ProfitGain + TXTARO OTP Setup Guide

## How registration works now

1. User enters **Ghana phone number** (+233) + Full name
2. System sends OTP via TXTARO
3. User enters the 6-digit code
4. Account is created

---

## DEMO MODE (current)

The website currently runs in **DEMO MODE**:
- No real SMS is sent
- Use OTP code: **123456**

To test: Register with any Ghana number → enter `123456`

---

## REAL TXTARO Integration

### 1. Get your TXTARO API Key
1. Go to https://txtaro.com
2. Create account / login
3. Generate an API key from the dashboard
4. Fund your wallet (starts from ~20 GHS)

### 2. TXTARO OTP Endpoints

**Send OTP**
```
POST https://otp.txtaro.com/api/v1/send
Authorization: Bearer YOUR_API_KEY
Content-Type: application/json

{
  "identifier": "+233241234567",
  "channel": "sms"
}
```

**Verify OTP**
```
POST https://otp.txtaro.com/api/v1/otp/verify
Authorization: Bearer YOUR_API_KEY
Content-Type: application/json

{
  "identifier": "+233241234567",
  "code": "123456"
}
```

### 3. Why you need a backend

Never put your TXTARO API key in the website JavaScript.  
Anyone can view it and steal your SMS credits.

You need a small backend that:
- Receives request from the website
- Calls TXTARO with your secret API key
- Returns success/fail to the website

### 4. Simple Node.js Backend Example

Save as `server.js`:

```js
const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

const TXTARO_API_KEY = 'YOUR_TXTARO_API_KEY_HERE'; // keep secret!

// SEND OTP
app.post('/api/otp/send', async (req, res) => {
  const { phone } = req.body;
  if (!phone) return res.json({ success: false, message: 'Phone required' });

  try {
    const response = await fetch('https://otp.txtaro.com/api/v1/send', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + TXTARO_API_KEY,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        identifier: phone,
        channel: 'sms'
      })
    });
    const data = await response.json();
    res.json({ success: data.success === true, message: data.message || 'OTP sent' });
  } catch (err) {
    res.json({ success: false, message: 'Failed to send OTP' });
  }
});

// VERIFY OTP
app.post('/api/otp/verify', async (req, res) => {
  const { phone, code } = req.body;
  if (!phone || !code) return res.json({ success: false, message: 'Phone and code required' });

  try {
    const response = await fetch('https://otp.txtaro.com/api/v1/otp/verify', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + TXTARO_API_KEY,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        identifier: phone,
        code: code
      })
    });
    const data = await response.json();
    res.json({ success: data.success === true, message: data.message || 'Verified' });
  } catch (err) {
    res.json({ success: false, message: 'Verification failed' });
  }
});

app.listen(3000, () => console.log('Backend running on port 3000'));
```

Run:
```
npm init -y
npm install express cors
node server.js
```

### 5. Connect the website

In `register.html`, change:

```js
var DEMO_MODE = false;
var BACKEND_URL = 'https://your-backend-domain.com';  // or http://localhost:3000 for testing
```

---

## PHP Backend Alternative (if you prefer PHP)

```php
<?php
// api/otp-send.php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');

$apiKey = 'YOUR_TXTARO_API_KEY';
$input = json_decode(file_get_contents('php://input'), true);
$phone = $input['phone'] ?? '';

$ch = curl_init('https://otp.txtaro.com/api/v1/send');
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POST => true,
  CURLOPT_HTTPHEADER => [
    'Authorization: Bearer ' . $apiKey,
    'Content-Type: application/json'
  ],
  CURLOPT_POSTFIELDS => json_encode([
    'identifier' => $phone,
    'channel' => 'sms'
  ])
]);
$response = curl_exec($ch);
curl_close($ch);
echo $response;
```

---

## Summary

| Mode | What happens |
|------|--------------|
| DEMO_MODE = true | No SMS. Use code **123456** |
| DEMO_MODE = false + backend | Real OTP via TXTARO SMS to Ghana numbers |

When you have your TXTARO API key, tell me and I can help you wire the backend fully.
